#include "Resources.h"
#include <SFML/Graphics.hpp>
#include <cmath>
#include <iostream>

// 静态成员初始化
Resources* Resources::m_instance = nullptr;

Resources& Resources::getInstance() {
    if (!m_instance) {
        m_instance = new Resources();
    }
    return *m_instance;
}

Resources::Resources() {
    loadResources();
}

void Resources::loadResources() {
    // 加载字体
    if (!m_font.loadFromFile("assets/fonts/font.ttf")) {
        std::cerr << "Warning: Failed to load font, using default" << std::endl;
    }
    
    // 加载纹理
    if (!m_hexHidden.loadFromFile("assets/textures/hex_hidden.png")) {
        createHexTexture(m_hexHidden, sf::Color(150, 150, 150), sf::Color(100, 100, 100));
        std::cerr << "Created fallback hidden hex texture" << std::endl;
    }
    
    if (!m_hexRevealed.loadFromFile("assets/textures/hex_revealed.png")) {
        createHexTexture(m_hexRevealed, sf::Color(200, 200, 200), sf::Color(150, 150, 150));
        std::cerr << "Created fallback revealed hex texture" << std::endl;
    }
    
    if (!m_mine.loadFromFile("assets/textures/mine.png")) {
        createMineTexture(m_mine);
        std::cerr << "Created fallback mine texture" << std::endl;
    }
    
    if (!m_mineRed.loadFromFile("assets/textures/mine_red.png")) {
        createMineTexture(m_mineRed, sf::Color::Red);
        std::cerr << "Created fallback red mine texture" << std::endl;
    }
    
    if (!m_flag.loadFromFile("assets/textures/flag.png")) {
        createFlagTexture(m_flag);
        std::cerr << "Created fallback flag texture" << std::endl;
    }
}

void Resources::createHexTexture(sf::Texture& texture, sf::Color fillColor, sf::Color outlineColor) {
    const int size = 64;
    sf::RenderTexture renderTex;
    if (!renderTex.create(size, size)) {
        return;
    }
    
    // 创建六边形形状
    sf::ConvexShape hex;
    hex.setPointCount(6);
    for (int i = 0; i < 6; i++) {
        float angle = 2.0f * 3.1415926535f / 6.0f * i;
        float x = size/2 + (size/2 - 4) * std::cos(angle);
        float y = size/2 + (size/2 - 4) * std::sin(angle);
        hex.setPoint(i, sf::Vector2f(x, y));
    }
    
    hex.setFillColor(fillColor);
    hex.setOutlineColor(outlineColor);
    hex.setOutlineThickness(2.0f);
    
    renderTex.clear(sf::Color::Transparent);
    renderTex.draw(hex);
    renderTex.display();
    
    texture = renderTex.getTexture();
}

void Resources::createMineTexture(sf::Texture& texture, sf::Color color) {
    const int size = 64;
    sf::RenderTexture renderTex;
    if (!renderTex.create(size, size)) {
        return;
    }
    
    // 创建地雷形状
    sf::CircleShape mineCircle(size/4);
    mineCircle.setFillColor(color);
    mineCircle.setOutlineColor(sf::Color::Black);
    mineCircle.setOutlineThickness(2.0f);
    mineCircle.setOrigin(size/4, size/4);
    mineCircle.setPosition(size/2, size/2);
    
    // 创建地雷顶部
    sf::CircleShape topCircle(size/8);
    topCircle.setFillColor(sf::Color::Black);
    topCircle.setOrigin(size/8, size/8);
    topCircle.setPosition(size/2, size/3);
    
    renderTex.clear(sf::Color::Transparent);
    renderTex.draw(mineCircle);
    renderTex.draw(topCircle);
    
    // 添加地雷刺
    for (int i = 0; i < 8; i++) {
        float angle = 2.0f * 3.1415926535f / 8.0f * i;
        float x1 = size/2 + (size/3) * std::cos(angle);
        float y1 = size/2 + (size/3) * std::sin(angle);
        float x2 = size/2 + (size/2.5f) * std::cos(angle);
        float y2 = size/2 + (size/2.5f) * std::sin(angle);
        
        sf::Vertex line[] = {
            sf::Vertex(sf::Vector2f(x1, y1), sf::Color::Black),
            sf::Vertex(sf::Vector2f(x2, y2), sf::Color::Black)
        };
        renderTex.draw(line, 2, sf::Lines);
    }
    
    renderTex.display();
    texture = renderTex.getTexture();
}

void Resources::createFlagTexture(sf::Texture& texture) {
    const int size = 64;
    sf::RenderTexture renderTex;
    if (!renderTex.create(size, size)) {
        return;
    }
    
    // 创建旗杆
    sf::RectangleShape pole(sf::Vector2f(4, size/1.5f));
    pole.setFillColor(sf::Color(150, 100, 50)); // 木色
    pole.setPosition(size/2 - 2, size/6);
    
    // 创建旗帜
    sf::ConvexShape flag;
    flag.setPointCount(4);
    flag.setPoint(0, sf::Vector2f(size/2, size/6));
    flag.setPoint(1, sf::Vector2f(size/2 + size/3, size/6 + size/6));
    flag.setPoint(2, sf::Vector2f(size/2, size/6 + size/3));
    flag.setPoint(3, sf::Vector2f(size/2, size/6));
    flag.setFillColor(sf::Color::Red);
    
    renderTex.clear(sf::Color::Transparent);
    renderTex.draw(pole);
    renderTex.draw(flag);
    renderTex.display();
    
    texture = renderTex.getTexture();
}

// 获取方法实现
sf::Font& Resources::getFont() { 
    return m_font; 
}

sf::Texture& Resources::getHexHidden() { 
    return m_hexHidden; 
}

sf::Texture& Resources::getHexRevealed() { 
    return m_hexRevealed; 
}

sf::Texture& Resources::getMine() { 
    return m_mine; 
}

sf::Texture& Resources::getMineRed() { 
    return m_mineRed; 
}

sf::Texture& Resources::getFlag() { 
    return m_flag; 
}