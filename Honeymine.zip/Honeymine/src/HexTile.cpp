#include "HexTile.h"
#include "Resources.h"
#include <cmath>
#include <iostream>

// 在源文件中定义静态常量
const float HexTile::HEX_RADIUS = 30.0f;
const float HexTile::HEX_HEIGHT = HEX_RADIUS * 2.0f;
const float HexTile::HEX_WIDTH = std::sqrt(3.0f) * HEX_RADIUS;

HexTile::HexTile() : 
    m_type(Type::Empty), 
    m_state(State::Hidden), 
    m_number(0) 
{
    // 创建六边形形状
    m_shape.setPointCount(6);
    for (int i = 0; i < 6; ++i) {
        float angle = 2.0f * 3.1415926535f / 6.0f * i;
        float x = HEX_RADIUS * std::cos(angle);
        float y = HEX_RADIUS * std::sin(angle);
        m_shape.setPoint(i, sf::Vector2f(x, y));
    }
    
    // 设置数字文本
    Resources& res = Resources::getInstance();
    m_numberText.setFont(res.getFont());
    m_numberText.setCharacterSize(30);
    m_numberText.setFillColor(sf::Color::Black);
    m_numberText.setOutlineThickness(1.25f);
    m_numberText.setOutlineColor(sf::Color::White);
    m_numberText.setOrigin(8, 18.75);
    
    updateAppearance();
}

void HexTile::setType(Type type) {
    m_type = type;
}

HexTile::Type HexTile::getType() const {
    return m_type;
}

HexTile::State HexTile::getState() const {
    return m_state;
}

void HexTile::setPosition(const sf::Vector2f& position) {
    m_shape.setPosition(position);
    m_numberText.setPosition(position);
}

void HexTile::setNumber(int number) {
    m_number = number;
    m_numberText.setString(std::to_string(number));
    
    // 根据数字设置颜色
    static const std::array<sf::Color, 6> numberColors = {
        sf::Color::Blue,
        sf::Color(0, 128, 0),  // 深绿
        sf::Color::Red,
        sf::Color(128, 0, 128), // 紫色
        sf::Color(128, 0, 0),   // 深红
        sf::Color(0, 128, 128)  // 青色
    };
    
    if (number > 0 && number <= 6) {
        m_numberText.setFillColor(numberColors[number - 1]);
    } else {
        m_numberText.setFillColor(sf::Color::Black);
    }
}

int HexTile::getNumber() const {
    return m_number;
}

void HexTile::reveal() {
    if (m_state != State::Flagged) {
        m_state = State::Revealed;
        updateAppearance();
    }
}

void HexTile::toggleFlag() {
    if (m_state == State::Hidden) {
        m_state = State::Flagged;
    } else if (m_state == State::Flagged) {
        m_state = State::Hidden;
    }
    updateAppearance();
}

void HexTile::explode() {
    if (m_type == Type::Mine) {
        m_state = State::Exploded;
        updateAppearance();
    }
}

void HexTile::reset() {
    m_state = State::Hidden;
    m_type = Type::Empty;
    m_number = 0;
    updateAppearance();
}

bool HexTile::contains(const sf::Vector2f& point) const {
    return m_shape.getGlobalBounds().contains(point);
}

sf::Vector2f HexTile::getPosition() const {
    return m_shape.getPosition();
}

void HexTile::updateAppearance() {
    Resources& res = Resources::getInstance();
    
    switch (m_state) {
        case State::Hidden:
            m_shape.setTexture(&res.getHexHidden());
            m_shape.setFillColor(sf::Color(200, 200, 200));
            break;
            
        case State::Revealed:
            m_shape.setTexture(&res.getHexRevealed());
            m_shape.setFillColor(sf::Color(240, 240, 240));
            break;
            
        case State::Flagged:
            m_shape.setTexture(&res.getHexHidden());
            m_shape.setFillColor(sf::Color(200, 200, 255));
            break;
            
        case State::Exploded:
            m_shape.setTexture(&res.getHexRevealed());
            m_shape.setFillColor(sf::Color(255, 200, 200));
            break;
    }
}

void HexTile::draw(sf::RenderTarget& target, sf::RenderStates states) const {
    target.draw(m_shape, states);
    
    // 只在显示数字时绘制文本
    if (m_state == State::Revealed && m_type == Type::Number && m_number > 0) {
        target.draw(m_numberText, states);
    }
    
    // 如果是旗帜状态，绘制旗帜
    if (m_state == State::Flagged) {
        Resources& res = Resources::getInstance();
        sf::Sprite flagSprite(res.getFlag());
        flagSprite.setOrigin(res.getFlag().getSize().x / 2, res.getFlag().getSize().y / 2);
        flagSprite.setPosition(m_shape.getPosition());
        target.draw(flagSprite, states);
    }
    
    // 如果是地雷状态，绘制地雷
    if ((m_state == State::Revealed || m_state == State::Exploded) && m_type == Type::Mine) {
        Resources& res = Resources::getInstance();
        sf::Sprite mineSprite(m_state == State::Exploded ? res.getMineRed() : res.getMine());
        mineSprite.setOrigin(res.getMine().getSize().x / 2, res.getMine().getSize().y / 2);
        mineSprite.setPosition(m_shape.getPosition());
        target.draw(mineSprite, states);
    }
}