#include "Board.h"
#include <random>
#include <queue>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <unordered_set>
#include <set>

Board::Board(int width, int height, int mines) : 
    m_boardSize(width, height),
    m_totalMines(mines),
    m_flaggedMines(0),
    m_revealedTiles(0),
    m_gameState(GameState::Uninitialized),
    m_position(90, 110),
    m_initialized(false)
{
    reset();
}

void Board::reset() {
    m_tiles.clear();
    m_tiles.resize(m_boardSize.y, std::vector<HexTile>(m_boardSize.x));
    m_flaggedMines = 0;
    m_revealedTiles = 0;
    m_gameState = GameState::Uninitialized;
    m_initialized = false;
    
    // 设置每个六边形瓦片的位置
    for (int row = 0; row < m_boardSize.y; ++row) {
        for (int col = 0; col < m_boardSize.x; ++col) {
            m_tiles[row][col].setPosition(axialToPixel(row, col));
        }
    }
}

void Board::safeInitialize(int safeRow, int safeCol) {
    if (m_initialized) return;
    
    // 确保安全位置及其周围没有地雷
    std::set<std::pair<int, int>> safePositions;
    
    // 添加安全位置本身
    safePositions.insert({safeRow, safeCol});
    
    // 添加所有邻居位置
    auto neighbors = getNeighbors(safeRow, safeCol);
    for (const auto& neighbor : neighbors) {
        safePositions.insert(neighbor);
    }
    
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> colDist(0, m_boardSize.x - 1);
    std::uniform_int_distribution<int> rowDist(0, m_boardSize.y - 1);
    
    int minesPlaced = 0;
    while (minesPlaced < m_totalMines) {
        int row = rowDist(gen);
        int col = colDist(gen);
        
        // 跳过安全位置
        if (safePositions.find({row, col}) != safePositions.end()) {
            continue;
        }
        
        if (m_tiles[row][col].getType() != HexTile::Type::Mine) {
            m_tiles[row][col].setType(HexTile::Type::Mine);
            minesPlaced++;
        }
    }
    
    calculateNumbers();
    m_initialized = true;
    m_gameState = GameState::Playing;
}

void Board::revealTile(int row, int col) {
    if (!isValidPosition(row, col) || 
        (m_gameState != GameState::Playing && m_gameState != GameState::Uninitialized)) {
        return;
    }
    
    HexTile& tile = m_tiles[row][col];
    
    if (tile.getState() == HexTile::State::Revealed || 
        tile.getState() == HexTile::State::Flagged) {
        return;
    }
    
    // 如果是第一次点击，先安全初始化
    if (m_gameState == GameState::Uninitialized) {
        safeInitialize(row, col);
    }
    
    tile.reveal();
    m_revealedTiles++;
    
    if (tile.getType() == HexTile::Type::Mine) {
        tile.explode();
        revealAllMines();
        m_gameState = GameState::Lose;
        return;
    }
    
    // 如果是空白瓦片，递归翻开周围的瓦片
    if (tile.getType() == HexTile::Type::Empty) {
        revealAdjacent(row, col);
    }
    
    // 检查胜利条件
    if (m_revealedTiles == m_boardSize.x * m_boardSize.y - m_totalMines) {
        m_gameState = GameState::Win;
    }
}

void Board::revealAdjacent(int startRow, int startCol) {
    std::queue<std::pair<int, int>> tilesToReveal;
    tilesToReveal.push({startRow, startCol});
    
    while (!tilesToReveal.empty()) {
        auto [row, col] = tilesToReveal.front();
        tilesToReveal.pop();
        
        auto neighbors = getNeighbors(row, col);
        for (const auto& neighbor : neighbors) {
            int r = neighbor.first;
            int c = neighbor.second;
            
            HexTile& tile = m_tiles[r][c];
            if (tile.getState() == HexTile::State::Hidden && 
                tile.getType() != HexTile::Type::Mine) {
                
                tile.reveal();
                m_revealedTiles++;
                
                if (tile.getType() == HexTile::Type::Empty) {
                    tilesToReveal.push({r, c});
                }
            }
        }
    }
}

void Board::flagTile(int row, int col) {
    if (!isValidPosition(row, col) || m_gameState != GameState::Playing) {
        return;
    }
    
    HexTile& tile = m_tiles[row][col];
    
    if (tile.getState() == HexTile::State::Hidden) {
        tile.toggleFlag();
        m_flaggedMines++;
    } else if (tile.getState() == HexTile::State::Flagged) {
        tile.toggleFlag();
        m_flaggedMines--;
    }
}

void Board::revealAllMines() {
    for (int row = 0; row < m_boardSize.y; ++row) {
        for (int col = 0; col < m_boardSize.x; ++col) {
            HexTile& tile = m_tiles[row][col];
            if (tile.getType() == HexTile::Type::Mine && 
                tile.getState() != HexTile::State::Exploded) {
                tile.reveal();
            }
        }
    }
}

Board::GameState Board::getGameState() const {
    return m_gameState;
}

int Board::getRemainingMines() const {
    return m_totalMines - m_flaggedMines;
}

sf::Vector2f Board::axialToPixel(int row, int col) {
    const float hexWidth = HexTile::HEX_WIDTH;
    const float hexHeight = HexTile::HEX_HEIGHT;
    
    // 偏移行 - 确保正确排列
    float offset = (row % 2 == 1) ? hexWidth / 2 : 0; // 奇数行向右偏移
    
    float x = col * hexWidth + offset;
    float y = row * hexHeight * 0.75f;
    
    // 添加位置偏移
    return sf::Vector2f(m_position.x + x, m_position.y + y);
}

sf::Vector2i Board::pixelToAxial(const sf::Vector2f& position) {
    const float hexWidth = HexTile::HEX_WIDTH;
    const float hexHeight = HexTile::HEX_HEIGHT;
    
    // 转换为棋盘坐标
    float x = position.x - m_position.x;
    float y = position.y - m_position.y;
    
    // 计算近似的行坐标
    float approxRow = y / (hexHeight * 0.75f);
    int row = static_cast<int>(std::round(approxRow));
    
    // 根据行偏移计算列
    float offset = (row % 2 == 1) ? hexWidth / 2 : 0;
    float approxCol = (x - offset) / hexWidth;
    int col = static_cast<int>(std::round(approxCol));
    
    return sf::Vector2i(row, col);
}

HexTile* Board::getTileAt(const sf::Vector2f& position) {
    // 计算轴向坐标
    sf::Vector2i axial = pixelToAxial(position);
    int row = axial.x;
    int col = axial.y;
    
    // 确保在边界内
    if (row >= 0 && row < m_boardSize.y && col >= 0 && col < m_boardSize.x) {
        return &m_tiles[row][col];
    }
    return nullptr;
}

bool Board::isValidPosition(int row, int col) const {
    return row >= 0 && row < m_boardSize.y && col >= 0 && col < m_boardSize.x;
}

void Board::draw(sf::RenderTarget& target, sf::RenderStates states) const {
    for (const auto& row : m_tiles) {
        for (const auto& tile : row) {
            target.draw(tile, states);
        }
    }
}

void Board::calculateNumbers() {
    for (int row = 0; row < m_boardSize.y; ++row) {
        for (int col = 0; col < m_boardSize.x; ++col) {
            if (m_tiles[row][col].getType() != HexTile::Type::Mine) {
                int mineCount = 0;
                
                // 获取所有相邻格子
                auto neighbors = getNeighbors(row, col);
                
                // 计算地雷数量
                for (const auto& neighbor : neighbors) {
                    int r = neighbor.first;
                    int c = neighbor.second;
                    
                    if (m_tiles[r][c].getType() == HexTile::Type::Mine) {
                        mineCount++;
                    }
                }
                
                // 设置格子类型和数字
                if (mineCount > 0) {
                    m_tiles[row][col].setType(HexTile::Type::Number);
                    m_tiles[row][col].setNumber(mineCount);
                } else {
                    m_tiles[row][col].setType(HexTile::Type::Empty);
                }
            }
        }
    }
}

std::vector<std::pair<int, int>> Board::getNeighbors(int row, int col) const {
    std::vector<std::pair<int, int>> neighbors;
    
    // 总是包含左右相邻
    if (col > 0) neighbors.push_back({row, col - 1}); // 左
    if (col < m_boardSize.x - 1) neighbors.push_back({row, col + 1}); // 右
    
    // 根据行号奇偶性确定其他相邻关系
    if (row % 2 == 0) { // 偶数行
        // 上方相邻
        if (row > 0) {
            if (col > 0) neighbors.push_back({row - 1, col - 1}); // 左上
            neighbors.push_back({row - 1, col});     // 正上
        }
        // 下方相邻
        if (row < m_boardSize.y - 1) {
            if (col > 0) neighbors.push_back({row + 1, col - 1}); // 左下
            neighbors.push_back({row + 1, col});     // 正下
        }
    } else { // 奇数行
        // 上方相邻
        if (row > 0) {
            neighbors.push_back({row - 1, col});     // 正上
            if (col < m_boardSize.x - 1) neighbors.push_back({row - 1, col + 1}); // 右上
        }
        // 下方相邻
        if (row < m_boardSize.y - 1) {
            neighbors.push_back({row + 1, col});     // 正下
            if (col < m_boardSize.x - 1) neighbors.push_back({row + 1, col + 1}); // 右下
        }
    }
    
    return neighbors;
}