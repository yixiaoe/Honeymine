#include "Game.h"
#include "Resources.h"
#include <iostream>

// 常量定义
const int Game::BOARD_WIDTH = 12;
const int Game::BOARD_HEIGHT = 12;
const int Game::MINES_COUNT = 20;

Game::Game() : 
    m_window(sf::VideoMode(800, 750), "Honeymine"),
    m_board(BOARD_WIDTH, BOARD_HEIGHT, MINES_COUNT),
    m_gameOver(false)
{
    Resources& res = Resources::getInstance();
    
    m_minesText.setFont(res.getFont());
    m_minesText.setCharacterSize(36);
    m_minesText.setFillColor(sf::Color::White);
    m_minesText.setPosition(20, 20);
    
    m_gameOverText.setFont(res.getFont());
    m_gameOverText.setCharacterSize(100);
    m_gameOverText.setFillColor(sf::Color::Red);
    m_gameOverText.setOutlineColor(sf::Color::Black);
    m_gameOverText.setOutlineThickness(3.0f);
    m_gameOverText.setPosition(250, 200);
    
    m_restartText.setFont(res.getFont());
    m_restartText.setCharacterSize(36);
    m_restartText.setFillColor(sf::Color(180, 180, 180));
    m_restartText.setString("Press R to restart");
    m_restartText.setPosition(320, 600);

    sf::FloatRect textBounds = m_restartText.getLocalBounds();
    m_restartText.setPosition((800 - textBounds.width) / 2, 350);
}

void Game::run() {
    while (m_window.isOpen()) {
        processEvents();
        update();
        render();
    }
}

void Game::processEvents() {
    sf::Event event;
    while (m_window.pollEvent(event)) {
        if (event.type == sf::Event::Closed) {
            m_window.close();
        }
        
        if (event.type == sf::Event::MouseButtonPressed) {
            // 允许在未初始化状态下点击
            if (m_board.getGameState() == Board::GameState::Playing || 
                m_board.getGameState() == Board::GameState::Uninitialized) {
                
                sf::Vector2f mousePos = m_window.mapPixelToCoords(
                    sf::Mouse::getPosition(m_window)
                );
                
                HexTile* tile = m_board.getTileAt(mousePos);
                if (tile) {
                    if (event.mouseButton.button == sf::Mouse::Left) {
                        sf::Vector2i axial = m_board.pixelToAxial(tile->getPosition());
                        m_board.revealTile(axial.x, axial.y);
                    } else if (event.mouseButton.button == sf::Mouse::Right) {
                        // 在未初始化状态下不允许标记
                        if (m_board.getGameState() == Board::GameState::Playing) {
                            sf::Vector2i axial = m_board.pixelToAxial(tile->getPosition());
                            m_board.flagTile(axial.x, axial.y);
                        }
                    }
                }
            }
        }
        
        if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::R) {
                resetGame();
            }
        }
    }
}

void Game::update() {
    m_minesText.setString("Mines: " + std::to_string(m_board.getRemainingMines()));
    
    if (m_board.getGameState() != Board::GameState::Playing) {
        m_gameOver = true;
    }
}

void Game::render() {
    m_window.clear(sf::Color(40, 40, 60));
    
    m_window.draw(m_board);
    drawUI();
    
    if (m_gameOver) {
        drawGameOver();
    }
    
    m_window.display();
}

void Game::drawUI() {
    m_window.draw(m_minesText);
    
    // 计算棋盘底部位置
    float boardBottom = m_board.getPosition().y + 
                        m_board.getSize().y * HexTile::HEX_HEIGHT * 0.75f;
    
    // 设置重启文本在棋盘下方
    sf::FloatRect restartBounds = m_restartText.getLocalBounds();
    m_restartText.setPosition(
        (800 - restartBounds.width) / 2,  // 水平居中
        boardBottom + 15  // 棋盘底部下方15像素
    );
    
    if (m_board.getGameState() == Board::GameState::Win) {
        m_gameOverText.setString("You Win!");
        m_gameOverText.setFillColor(sf::Color(0, 200, 20));

        // 添加黑色边框
        m_gameOverText.setOutlineColor(sf::Color::Black);
        m_gameOverText.setOutlineThickness(3.0f);

        sf::FloatRect winBounds = m_gameOverText.getLocalBounds();
        m_gameOverText.setPosition((800 - winBounds.width) / 2, 200);
        m_window.draw(m_gameOverText);
        m_window.draw(m_restartText);
    } else if (m_board.getGameState() == Board::GameState::Lose) {
        m_gameOverText.setString("Game Over!");
        m_gameOverText.setFillColor(sf::Color(177, 0, 0));

        // 添加黑色边框
        m_gameOverText.setOutlineColor(sf::Color::Black);
        m_gameOverText.setOutlineThickness(3.0f);
        
        sf::FloatRect loseBounds = m_gameOverText.getLocalBounds();
        m_gameOverText.setPosition((800 - loseBounds.width) / 2, 200);   
        m_window.draw(m_gameOverText);
        m_window.draw(m_restartText);
    }
}

void Game::resetGame() {
    m_board = Board(BOARD_WIDTH, BOARD_HEIGHT, MINES_COUNT);
    m_gameOver = false;
}

void Game::drawGameOver() {
    // 已经在drawUI中处理
}