#pragma once
#include <vector>
#include <SFML/Graphics.hpp>
#include "HexTile.h"

class Board : public sf::Drawable {
public:
    enum class GameState { Uninitialized, Playing, Win, Lose };
    
    Board(int width, int height, int mines);
    
    void reset();
    void revealTile(int row, int col);
    void flagTile(int row, int col);
    void revealAllMines();
    
    GameState getGameState() const;
    int getRemainingMines() const;
    
    sf::Vector2f getPosition() const { return m_position; }
    sf::Vector2i getSize() const { return m_boardSize; }
    
    HexTile* getTileAt(const sf::Vector2f& position);
    
    sf::Vector2f axialToPixel(int row, int col);
    sf::Vector2i pixelToAxial(const sf::Vector2f& position);
    
private:
    void draw(sf::RenderTarget& target, sf::RenderStates states) const override;
    void safeInitialize(int safeRow, int safeCol);
    
    // 将以下方法从 private 移动到 public 或者保持 private 但确保有实现
    void placeMines();
    void calculateNumbers();
    void revealAdjacent(int row, int col);
    bool isValidPosition(int row, int col) const;
    std::vector<std::pair<int, int>> getNeighbors(int row, int col) const;
    
    std::vector<std::vector<HexTile>> m_tiles;
    sf::Vector2i m_boardSize;
    int m_totalMines;
    int m_flaggedMines;
    int m_revealedTiles;
    GameState m_gameState;
    sf::Vector2f m_position;
    bool m_initialized;
};