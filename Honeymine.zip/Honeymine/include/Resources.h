#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>

class Resources {
public:
    static Resources& getInstance();
    
    sf::Font& getFont();
    sf::Texture& getHexHidden();
    sf::Texture& getHexRevealed();
    sf::Texture& getMine();
    sf::Texture& getMineRed();
    sf::Texture& getFlag();
    
private:
    Resources();
    Resources(const Resources&) = delete;
    Resources& operator=(const Resources&) = delete;
    
    void loadResources();
    void createHexTexture(sf::Texture& texture, sf::Color fillColor, sf::Color outlineColor);
    void createMineTexture(sf::Texture& texture, sf::Color color = sf::Color::Black);
    void createFlagTexture(sf::Texture& texture);
    
    static Resources* m_instance;
    
    sf::Font m_font;
    sf::Texture m_hexHidden;
    sf::Texture m_hexRevealed;
    sf::Texture m_mine;
    sf::Texture m_mineRed;
    sf::Texture m_flag;
};