#pragma once
#include <SFML/Graphics.hpp>
#include "Board.h"

class Game {
public:
    Game();
    void run();

private:
    void processEvents();
    void update();
    void render();
    void resetGame();
    void drawUI();
    void drawGameOver();
    
    // 常量
    static const int BOARD_WIDTH;
    static const int BOARD_HEIGHT;
    static const int MINES_COUNT;
    
    sf::RenderWindow m_window;
    Board m_board;
    sf::Text m_minesText;
    sf::Text m_gameOverText;
    sf::Text m_restartText;
    
    bool m_gameOver;
};