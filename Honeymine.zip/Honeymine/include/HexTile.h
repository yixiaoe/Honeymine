#pragma once
#include <SFML/Graphics.hpp>
#include <array>

class HexTile : public sf::Drawable {
public:
    enum class State { Hidden, Revealed, Flagged, Exploded };
    enum class Type { Empty, Mine, Number };
    
    HexTile();
    
    void setPosition(const sf::Vector2f& position);
    void setType(Type type);
    Type getType() const;
    State getState() const;
    void setNumber(int number);
    int getNumber() const;
    void reveal();
    void toggleFlag();
    void explode();
    void reset();
    
    bool contains(const sf::Vector2f& point) const;
    sf::Vector2f getPosition() const;
    
    // 静态常量
    static const float HEX_RADIUS;
    static const float HEX_HEIGHT;
    static const float HEX_WIDTH;
    
private:
    void draw(sf::RenderTarget& target, sf::RenderStates states) const override;
    void updateAppearance();
    
    sf::ConvexShape m_shape;
    sf::Text m_numberText;
    
    Type m_type;
    State m_state;
    int m_number;
};